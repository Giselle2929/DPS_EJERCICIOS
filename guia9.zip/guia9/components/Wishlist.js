import React from 'react';
import { View, Text, FlatList, Button, StyleSheet } from 'react-native';

export default function Wishlist({ wishlist, setPantalla }) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>⭐ Lista de Deseos</Text>

      {wishlist.length === 0 ? (
        <Text>No hay productos guardados</Text>
      ) : (
        <FlatList
          data={wishlist}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.item}>
              <Text style={styles.nombre}>{item.nombre}</Text>
              <Text>{item.precio}</Text>
            </View>
          )}
        />
      )}

      <Button title="Volver" onPress={() => setPantalla("home")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20
  },
  titulo: {
    fontSize: 22,
    marginBottom: 20,
    textAlign: 'center'
  },
  item: {
    padding: 10,
    borderBottomWidth: 1
  },
  nombre: {
    fontWeight: 'bold'
  }
});