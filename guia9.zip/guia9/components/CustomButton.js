import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

export default function CustomButton({ title, onPress }) {
  return (
    <TouchableOpacity style={styles.boton} onPress={onPress}>
      <Text style={styles.texto}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  boton: {
    backgroundColor: '#2196F3',
    padding: 12,
    marginVertical: 10,
    borderRadius: 8
  },
  texto: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 16
  }
});