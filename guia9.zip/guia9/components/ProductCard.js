import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ProductCard({ producto }) {
  return (
    <View style={styles.card}>
      <Text style={styles.nombre}>{producto.nombre}</Text>
      <Text>{producto.precio}</Text>
      <Text>{producto.descripcion}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 15,
    borderWidth: 1,
    borderRadius: 10,
    marginVertical: 10
  },
  nombre: {
    fontWeight: 'bold',
    fontSize: 16
  }
});