import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import CustomButton from './CustomButton';

export default function Home({ setPantalla }) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>📱 Escáner de Productos</Text>

      <CustomButton 
        title="Escanear Producto" 
        onPress={() => setPantalla("scanner")} 
      />

      <CustomButton 
        title="Ver Lista de Deseos" 
        onPress={() => setPantalla("wishlist")} 
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', padding:20 },
  titulo: { fontSize:22, textAlign:'center', marginBottom:20 }
});