import React from 'react';
import { View, StyleSheet, Alert } from 'react-native';
import ProductCard from './ProductCard';
import CustomButton from './CustomButton';

export default function Producto({ producto, setPantalla, wishlist, setWishlist }) {

  const agregar = () => {
    setWishlist([...wishlist, producto]);
    Alert.alert("Agregado", "Producto añadido a la lista");
  };

  return (
    <View style={styles.container}>
      <ProductCard producto={producto} />

      <CustomButton title="Agregar a Wishlist" onPress={agregar} />
      <CustomButton title="Volver" onPress={() => setPantalla("home")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', padding:20 }
});