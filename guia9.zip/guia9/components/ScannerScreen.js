import * as React from 'react';
import { useState } from 'react';
import { Text, View, Button, StyleSheet } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

export default function ScanneScreen({ setPantalla, setProducto }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [escaneado, setEscaneado] = useState(false);

  const obtenerProducto = (codigo) => {
    return {
      id: codigo,
      nombre: "Producto " + codigo,
      precio: "$" + (Math.random() * 10 + 1).toFixed(2),
      descripcion: "Producto escaneado correctamente"
    };
  };

  const escanear = ({ data }) => {
    setEscaneado(true);
    const producto = obtenerProducto(data);
    setProducto(producto);
    setPantalla("producto");
  };

  if (!permission) {
    return <Text>Solicitando permisos...</Text>;
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <Text>No hay acceso a la cámara</Text>
        <Button title="Permitir cámara" onPress={requestPermission} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CameraView
        style={StyleSheet.absoluteFillObject}
        barcodeScannerSettings={{
          barcodeTypes: ["qr", "ean13", "code128"],
        }}
        onBarcodeScanned={escaneado ? undefined : escanear}
      />

      {escaneado && (
        <Button title="Escanear otra vez" onPress={() => setEscaneado(false)} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});