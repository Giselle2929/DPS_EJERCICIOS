import * as React from 'react';
import { useState } from 'react';

import Home from './components/Home';
import Scanner from './components/ScannerScreen';
import Producto from './components/Producto'; // ← CORREGIDO
import Wishlist from './components/Wishlist';

export default function App() {
  const [pantalla, setPantalla] = useState("home");
  const [producto, setProducto] = useState(null);
  const [wishlist, setWishlist] = useState([]);

  return (
    <>
      {pantalla === "home" && <Home setPantalla={setPantalla} />}

      {pantalla === "scanner" && (
        <Scanner 
          setPantalla={setPantalla} 
          setProducto={setProducto} 
        />
      )}

      {pantalla === "producto" && (
        <Producto
          producto={producto}
          setPantalla={setPantalla}
          wishlist={wishlist}
          setWishlist={setWishlist}
        />
      )}

      {pantalla === "wishlist" && (
        <Wishlist 
          wishlist={wishlist} 
          setPantalla={setPantalla} 
        />
      )}
    </>
  );
}